<?php if(! defined('BASEPATH')) exit('No direct script access allowed');

class GestionContenu extends CI_Model
{
    public function Menu()
    {
        $query = $this->db->query('SELECT * from Menu');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomMenu']=$row['nomMenu'];
            $valiny[$i]['idSection']=$row['idSection'];
        
            $i=$i+1;
        }
        return $valiny;
    }  

    public function insertionMenu($nommenu, $section)
    {
        $query = $this->db->query("insert into menu values(null,'$nommenu','$section')");
      
    } 
}