<?php if(! defined('BASEPATH')) exit('No direct script access allowed');

class FanakaModel extends CI_Model
{
    public function Tous()
    {
        $query = $this->db->query('SELECT * from Fanaka');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idFanaka']=$row['idFanaka'];
            $valiny[$i]['nomFanaka']=$row['nomFanaka'];
            $valiny[$i]['prixFanaka']=$row['prixFanaka'];
            $valiny[$i]['SaryFanaka']=$row['SaryFanaka'];
       
              $i=$i+1;
        }
        return $valiny;
    }   
    public function offrespecial()
    {
        $query = $this->db->query('SELECT * from Fanaka limit 6');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomFanaka']=$row['nomFanaka'];
            $valiny[$i]['prixFanaka']=$row['prixFanaka'];
             $valiny[$i]['SaryFanaka']=$row['SaryFanaka'];
              $i=$i+1;
        }
        return $valiny;
    } 
    public function prixmora()
    {
        $query = $this->db->query('SELECT * from Fanaka where idcategoriefanaka=1 and prixfanaka<=200000 or idcategoriefanaka=2 and prixfanaka<=200000 or idcategoriefanaka=3 and prixfanaka<=50000 or idcategoriefanaka=4 and prixfanaka<=14000');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomFanaka']=$row['nomFanaka'];
            $valiny[$i]['prixFanaka']=$row['prixFanaka'];
             $valiny[$i]['SaryFanaka']=$row['SaryFanaka'];
              $i=$i+1;
        }
        return $valiny;
    } 
    public function testlogin($wawa)
    {
        $query = $this->db->query('select * from admin');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['login']=$row['login'];
            
              $i=$i+1;
        }
        if($wawa==$valiny[$i]['login'])
        {
        return 1;
        }
        else
        {
        return 0;
        }
    } 
    


}