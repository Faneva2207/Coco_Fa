<?php if(! defined('BASEPATH')) exit('No direct script access allowed');

class Fonction extends CI_Model
{
    public function Categorie()
    {
        $query = $this->db->query('SELECT * FROM categorie');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['nomCategorie']=$row['nomCategorie'];
           
              $i=$i+1;
        }
        return $valiny;
    }   
   
    public function CategorieCondition($idCategorie)
    {
        $query = $this->db->query('SELECT * FROM categorie WHERE idCategorie='.$idCategorie.' ');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['nomCategorie']=$row['nomCategorie'];
           
              $i=$i+1;
        }
        return $valiny;
    }   
     public function AllProduit()
    {
        $query = $this->db->query('SELECT * FROM produit');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idProduit']=$row['idProduit'];
            $valiny[$i]['nomProduit']=$row['nomProduit'];
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['quantite']=$row['quantite'];
            $valiny[$i]['image']=$row['image'];
            $valiny[$i]['unite']=$row['unite'];
          
              $i=$i+1;
        }
        return $valiny;
    }   
      public function produitCategorie($idCategorie)
    {
        $query = $this->db->query('SELECT * FROM produit WHERE idCategorie='.$idCategorie.' ');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idProduit']=$row['idProduit'];
            $valiny[$i]['nomProduit']=$row['nomProduit'];
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['quantite']=$row['quantite'];
            $valiny[$i]['image']=$row['image'];
            $valiny[$i]['unite']=$row['unite'];
          
              $i=$i+1;
        }
        return $valiny;
    }   
   
    public function ProduitCondition($idProduit)
    {
        $query = $this->db->query('SELECT * FROM produit WHERE idProduit='.$idProduit.' ');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idProduit']=$row['idProduit'];
            $valiny[$i]['nomProduit']=$row['nomProduit'];
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['quantite']=$row['quantite'];
            $valiny[$i]['image']=$row['image'];
            $valiny[$i]['unite']=$row['unite'];
          
              $i=$i+1;
        }
        return $valiny;
    }   
     public function ProduitCat1()
    {
        $query = $this->db->query('SELECT * FROM produit WHERE idCategorie= 1');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idProduit']=$row['idProduit'];
            $valiny[$i]['nomProduit']=$row['nomProduit'];
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['quantite']=$row['quantite'];
            $valiny[$i]['image']=$row['image'];
            $valiny[$i]['unite']=$row['unite'];
          
              $i=$i+1;
        }
        return $valiny;
    }   
     public function ProduitCat2()
    {
        $query = $this->db->query('SELECT * FROM produit WHERE idCategorie= 2');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idProduit']=$row['idProduit'];
            $valiny[$i]['nomProduit']=$row['nomProduit'];
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['quantite']=$row['quantite'];
            $valiny[$i]['image']=$row['image'];
            $valiny[$i]['unite']=$row['unite'];
          
              $i=$i+1;
        }
        return $valiny;
    }   
         public function ProduitCat3()
    {
        $query = $this->db->query('SELECT * FROM produit WHERE idCategorie= 3');
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idProduit']=$row['idProduit'];
            $valiny[$i]['nomProduit']=$row['nomProduit'];
            $valiny[$i]['idCategorie']=$row['idCategorie'];
            $valiny[$i]['quantite']=$row['quantite'];
            $valiny[$i]['image']=$row['image'];
            $valiny[$i]['unite']=$row['unite'];
          
              $i=$i+1;
        }
        return $valiny;
    }   
         public function testLogin($login, $Mdp)
    {
        $query = $this->db->query("SELECT count(*)  FROM administrateur WHERE login='".$login."' and mdp='".$Mdp."' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['count(*)']=$row['count(*)'];
            
          
              $i=$i+1;
        }
        return $valiny;
    }   

         public function suppression($nomProduit)
    {
        $query = $this->db->query("DELETE FROM produit WHERE nomProduit='".$nomProduit."' ");
        
    }   
           public function suppCategorie($nomCategorie)
    {
        $query = $this->db->query("DELETE FROM categorie WHERE nomCategorie='".$nomCategorie."' ");
        
    }    
    public function insertionCategorie($nomCategorie)
    {
        $query = $this->db->query("INSERT INTO Categorie VALUES(null,'$nomCategorie')");
      
    }
     public function insertionProduit($n, $c, $q, $u, $i)
    {
        $query = $this->db->query("INSERT INTO produit VALUES(null,'$n', $c, $q, '$u', '$i')");
      
    } 
     public function updateC($nomCategorie, $idCategorie)
    {
        $query = $this->db->query("UPDATE Categorie SET nomCategorie='$nomCategorie' WHERE idCategorie= $idCategorie");
      
    }
      public function updateP($np, $cp, $qp, $up, $ip, $idProduit)
    {
        $query = $this->db->query("UPDATE produit SET nomProduit='$np', idCategorie=$cp, quantite=$qp, unite='$up', image='$ip' WHERE idProduit=$idProduit");
      
    } 

}