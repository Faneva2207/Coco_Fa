<?php if(! defined('BASEPATH')) exit('No direct script access allowed');

class FonctionModel extends CI_Model
{
    
 public function creationProjet($nom, $contact, $localisation, $idUM, $dateD, $dateF, $Capital)
    {
        $query = $this->db->query("insert into configuration values(null,'$nom',$contact,'$localisation',$idUM,'$dateD','$dateF',$Capital)");
      
    } 
    public function prendreUniteM()
    {
        $query = $this->db->query("SELECT * from unitemonetaire ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idUniteMonetaire']=$row['idUniteMonetaire'];
            $valiny[$i]['nomUniteMonetaire']=$row['nomUniteMonetaire'];
       
              $i=$i+1;
        }
        return $valiny;
    }
    /*anaovana anle anaranle entreprise ao amle votre projet*/
 public function prendreNom($nomEntreprise)
    {
        $query = $this->db->query("SELECT * from configuration where nomEntreprise='".$nomEntreprise."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomEntreprise']=$row['nomEntreprise'];
            $i=$i+1;
        }
        return $valiny;
    }
    /*apesaina amle idiritra projet ao am index*/
    public function AllProject()
    {
        $query = $this->db->query("SELECT * from configuration");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomEntreprise']=$row['nomEntreprise'];
            $i=$i+1;
        }
        return $valiny;
    }
     public function AllTypeOperation()
    {
        $query = $this->db->query("SELECT * from typeoperation");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idTypeOperation']=$row['idTypeOperation'];
            $valiny[$i]['nomTypeOperation']=$row['nomTypeOperation'];
            
            $i=$i+1;
        }
        return $valiny;
    }
    public function AjoutOperation($idE,$idCompteDebit,$idCompteCredit,$libelleBilan,$debit,$credit,$ref,$date)
    {
          $query = $this->db->query("insert into operation values(null,$idE,$idCompteDebit,$idCompteCredit,'$libelleBilan',$debit,$credit,$ref,'$date')");
      
    }
     public function ConfigurationCondition($nomE)
    {
        $query = $this->db->query("SELECT * from configuration where nomEntreprise='".$nomE."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['idConfiguration']=$row['idConfiguration'];
            $i=$i+1;
        }
        return $valiny;
    }


   public function OperationCondition($nomEn)
    {
        $query = $this->db->query("SELECT * from operation join configuration on operation.idConfiguration=configuration.idConfiguration join typeoperation on operation.type=typeoperation.idTypeOperation join unitemonetaire on configuration.idUniteMonetaire=unitemonetaire.idUNiteMonetaire where configuration.nomEntreprise='".$nomEn."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomEntreprise']=$row['nomEntreprise'];
            $valiny[$i]['codeCompte']=$row['codeCompte'];
            $valiny[$i]['nomTypeOperation']=$row['nomTypeOperation'];
             $valiny[$i]['nomUniteMonetaire']=$row['nomUniteMonetaire'];
            $valiny[$i]['nom']=$row['nom'];
            $valiny[$i]['nomBilan']=$row['nomBilan'];
            $valiny[$i]['debit']=$row['debit'];
            $valiny[$i]['credit']=$row['credit'];
            $valiny[$i]['dateOperation']=$row['dateOperation'];
            $valiny[$i]['ArgentConcernant']=$row['ArgentConcernant'];
            $valiny[$i]['Facture']=$row['Facture'];
             $valiny[$i]['capital']=$row['capital'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
     public function unite($nomEn)
    {
        $query = $this->db->query("SELECT * from operation join configuration on operation.idConfiguration=configuration.idConfiguration join typeoperation on operation.type=typeoperation.idTypeOperation join unitemonetaire on configuration.idUniteMonetaire=unitemonetaire.idUNiteMonetaire where configuration.nomEntreprise='".$nomEn."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
          
             $valiny[$i]['nomUniteMonetaire']=$row['nomUniteMonetaire'];
           
            
            
            $i=$i+1;
        }
        return $valiny;
    }
    public function recupCapital($nomEn)
    {
        $query = $this->db->query("SELECT * from configuration where nomEntreprise='".$nomEn."' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['capital']=$row['capital'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
     public function OperationConditionActif($nomEn)
    {
        $query = $this->db->query("SELECT * from operation join configuration on operation.idConfiguration=configuration.idConfiguration join typeoperation on operation.type=typeoperation.idTypeOperation where configuration.nomEntreprise='".$nomEn."'  ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomEntreprise']=$row['nomEntreprise'];
            $valiny[$i]['codeCompte']=$row['codeCompte'];
            $valiny[$i]['nomTypeOperation']=$row['nomTypeOperation'];
            $valiny[$i]['nom']=$row['nom'];
            $valiny[$i]['nomBilan']=$row['nomBilan'];
            $valiny[$i]['debit']=$row['debit'];
            $valiny[$i]['credit']=$row['credit'];
            $valiny[$i]['dateOperation']=$row['dateOperation'];
            $valiny[$i]['ArgentConcernant']=$row['ArgentConcernant'];
            $valiny[$i]['Facture']=$row['Facture'];
            
            $i=$i+1;
        }
        return $valiny;
    }
     public function OperationConditionPassif($nomEn)
    {
        $query = $this->db->query("SELECT * from operation join configuration on operation.idConfiguration=configuration.idConfiguration join typeoperation on operation.type=typeoperation.idTypeOperation where configuration.nomEntreprise='".$nomEn."' and typeoperation.nomTypeOperation='passif' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['nomEntreprise']=$row['nomEntreprise'];
             $valiny[$i]['codeCompte']=$row['codeCompte'];
            $valiny[$i]['nomTypeOperation']=$row['nomTypeOperation'];
            $valiny[$i]['nom']=$row['nom'];
            $valiny[$i]['nomBilan']=$row['nomBilan'];
            $valiny[$i]['debit']=$row['debit'];
            $valiny[$i]['credit']=$row['credit'];
            $valiny[$i]['dateOperation']=$row['dateOperation'];
            $valiny[$i]['ArgentConcernant']=$row['ArgentConcernant'];
            $valiny[$i]['Facture']=$row['Facture'];
            
            $i=$i+1;
        }
        return $valiny;
    }
    /*andrana manipulation capital*/
    public function recupDebit($nomConf)
    {
         $query = $this->db->query("SELECT debit,credit from operation join configuration on operation.idConfiguration=configuration.idConfiguration where configuration.nomEntreprise='".$nomConf."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['debit']=$row['debit'];
             $valiny[$i]['credit']=$row['credit'];
           
            
            $i=$i+1;
        }
        return $valiny;
    }
    /*gestion banque*/
    public function sommeArgent($conf)
    {
        $query = $this->db->query("SELECT SUM(argentConcernant) from operation join configuration on operation.idConfiguration=configuration.idConfiguration join typeoperation on operation.type=typeoperation.idTypeOperation where configuration.nomEntreprise='".$conf."' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['SUM(argentConcernant)']=$row['SUM(argentConcernant)'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
    public function sommeArgent2($conf)
    {
        $query = $this->db->query("SELECT SUM(argentConcernant) from operation join configuration on operation.idConfiguration=configuration.idConfiguration join typeoperation on operation.type=typeoperation.idTypeOperation where configuration.nomEntreprise='".$conf."' and typeoperation.nomTypeOperation='actif' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['SUM(argentConcernant)']=$row['SUM(argentConcernant)'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
      public function sommeArgentPassif($conf)
    {
        $query = $this->db->query("SELECT SUM(argentConcernant) from operation join configuration on operation.idConfiguration=configuration.idConfiguration join typeoperation on operation.type=typeoperation.idTypeOperation where configuration.nomEntreprise='".$conf."' and typeoperation.nomTypeOperation='Passif' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['SUM(argentConcernant)']=$row['SUM(argentConcernant)'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }

    public function creationPcg($classe, $code, $libelle)
    {
        $query = $this->db->query("insert into pcg values(null,$classe,$code,'$libelle')");
      
    } 
      public function creationCompte($codepcg, $valeur, $entr)
    {
        $query = $this->db->query("insert into compte values(null, $codepcg ,$valeur,$entr)");
      
    } 

 public function pcgCondition($libelle)
    {
        $query = $this->db->query("select * from pcg where libellePcg='".$libelle."' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['idPcg']=$row['idPcg'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
     public function AllPcg()
    {
        $query = $this->db->query("select * from pcg");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['libellePcg']=$row['libellePcg'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }

         public function compteCondition($nomEnt)
    {
        $query = $this->db->query("select * from compte join configuration on compte.idConfiguration=configuration.idConfiguration join pcg on compte.idPcg=pcg.idPcg where configuration.nomEntreprise='".$nomEnt."' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['idCompte']=$row['idCompte'];
             $valiny[$i]['libellePcg']=$row['libellePcg'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
        public function fonctionAndrana($andrana)
    {
        $query = $this->db->query("SELECT * from compte join pcg on compte.idPcg=pcg.idPcg join operation on compte.idCompte=operation.idCompteDebit  where pcg.CodePcg=".$andrana." ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['idCompte']=$row['idCompte'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
       public function Operation($nomEn)
    {
        $query = $this->db->query("SELECT * from operation join configuration on operation.idConfiguration=configuration.idConfiguration join compte on operation.idCompteDebit=compte.idCompte join pcg on compte.idPcg=pcg.idPcg where configuration.nomEntreprise='".$nomEn."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['dateOperation']=$row['dateOperation'];
            $valiny[$i]['CodePcg']=$row['CodePcg'];
            
            $valiny[$i]['idCompteDebit']=$row['idCompteDebit'];
            $valiny[$i]['libellePcg']=$row['libellePcg'];
             $valiny[$i]['referenceFacture']=$row['referenceFacture'];
           
            $valiny[$i]['idCompteCredit']=$row['idCompteCredit'];
            $valiny[$i]['debit']=$row['debit'];

             $valiny[$i]['credit']=$row['credit'];
            
            $i=$i+1;
        }
        return $valiny;
    }
     public function Operation2($nomEn)
    {
        $query = $this->db->query("SELECT DISTINCT * from operation join configuration on operation.idConfiguration=configuration.idConfiguration join compte on operation.idCompteCredit=compte.idCompte join pcg on compte.idPcg=pcg.idPcg where configuration.nomEntreprise='".$nomEn."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['dateOperation']=$row['dateOperation'];
            
            $valiny[$i]['idCompteDebit']=$row['idCompteDebit'];
            $valiny[$i]['libellePcg']=$row['libellePcg'];
            $valiny[$i]['CodePcg']=$row['CodePcg'];


            $valiny[$i]['idCompteCredit']=$row['idCompteCredit'];
            $valiny[$i]['debit']=$row['debit'];

             $valiny[$i]['credit']=$row['credit'];
            
            $i=$i+1;
        }
        return $valiny;
    }
      public function makaLibelle($code)
    {
        $query = $this->db->query("SELECT * from pcg where codePcg=".$code." ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['libellePcg']=$row['libellePcg'];
            
           
            
            $i=$i+1;
        }
        return $valiny;
    }
    public function compteclasse2($config)
    {
        $query = $this->db->query("SELECT * from compte join pcg on compte.idPcg=pcg.idPcg join configuration on compte.idConfiguration=configuration.idConfiguration join operation on compte.idConfiguration=operation.idConfiguration where configuration.nomEntreprise='".$config."'");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['libellePcg']=$row['libellePcg'];
            $valiny[$i]['libelleBilan']=$row['libelleBilan'];
            $valiny[$i]['debit']=$row['debit'];
             $valiny[$i]['credit']=$row['credit'];
           
            
            $i=$i+1;
        }
        return $valiny;
    }
     public function compteclasse3($config)
    {
        $query = $this->db->query("SELECT * from compte join pcg on compte.idPcg=pcg.idPcg join configuration on compte.idConfiguration=configuration.idConfiguration join operation on compte.idConfiguration=operation.idConfiguration where configuration.nomEntreprise='".$config."'  ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['libellePcg']=$row['libellePcg'];
            $valiny[$i]['libelleBilan']=$row['libelleBilan'];
            $valiny[$i]['debit']=$row['debit'];
             $valiny[$i]['credit']=$row['credit'];
           
            
            $i=$i+1;
        }
        return $valiny;
    }
     public function comptedeResultat($config)
    {
        $query = $this->db->query("SELECT * from compte join pcg on compte.idPcg=pcg.idPcg join configuration on compte.idConfiguration=configuration.idConfiguration join operation on compte.idConfiguration=operation.idConfiguration where configuration.nomEntreprise='".$config." and pcg.classe=6");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
            $valiny[$i]['libellePcg']=$row['libellePcg'];
            $valiny[$i]['libelleBilan']=$row['libelleBilan'];
            $valiny[$i]['debit']=$row['debit'];
             $valiny[$i]['credit']=$row['credit'];
           
            
            $i=$i+1;
        }
        return $valiny;
    }
    public function sommedebit($conf)
    {
        $query = $this->db->query("SELECT SUM(debit) from operation join configuration on operation.idConfiguration=configuration.idConfiguration where configuration.nomEntreprise='".$conf."' ");
        $valiny = array();
        $i=0;

        foreach($query->result_array() as $row)
        {
           
             $valiny[$i]['SUM(debit)']=$row['SUM(debit)'];
            
            
            $i=$i+1;
        }
        return $valiny;
    }
}