<!DOCTYPE HTML>
<!--
	Dopetrope by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Index</title>


		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="<?php echo base_url("assets/css/main.css");?>" />
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<section id="header">

					<!-- Logo -->
						<h1><a href="<?php echo base_url("index.php/welcome/index");?>">COCO</a></h1>

					<!-- Nav -->
						<nav id="nav">
							<ul>
								<li class="current"><a href="<?php echo base_url('index.php/welcome/index');?>">Accueil</a></li>
								<li>
									<a href="#">Categorie</a>
									<ul>
										<?php foreach($Categorie as $value){ ?>
										<li><a href="#"><?php echo $value['nomCategorie'];?></a></li>
										<?php } ?>
										
										
									</ul>
								</li>
								<li><a href="<?php echo base_url('index.php/welcome/RedirectionContact');?>">Contact</a></li>
								<li>
									<a href="#">Connexion</a>
									<ul>
										
										<li><a href="<?php echo base_url("index.php/welcome/Connexion");?>">Administrateur</a></li>
										
									</ul>
								</li>
								
							</ul>
						</nav>

					<!-- Banner -->