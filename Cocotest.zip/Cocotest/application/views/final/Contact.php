<?php include('include/header.php');?>
					<!-- Banner -->
					<!-- Banner -->
						<section id="banner">
							<header>
								
	    <div class="container">
		  <div class="contact-grid-agile-w3s">
				<div class="col-md-4 contact-grid-agile-w3">
						<div class="contact-grid-agile-w31">
							<i class="fa fa-map-marker" aria-hidden="true"></i>
							<h4>Addresse</h4>
							<p>IJB 123 <span>ITAOSY</span></p>
						</div>
					</div>
					<div class="col-md-4 contact-grid-agile-w3">
						<div class="contact-grid-agile-w32">
							<i class="fa fa-phone" aria-hidden="true"></i>
							<h4>Numero</h4>
							<p>034 95 439 71<span>032 40 655 42</span></p>
						</div>
					</div>
					<div class="col-md-4 contact-grid-agile-w3">
						<div class="contact-grid-agile-w33">
							<i class="fa fa-envelope-o" aria-hidden="true"></i>
							<h4>Email</h4>
							<p><a href="#">nirina.neva@gmail.com</a><span><a href="#">Ly@gmail.com</a></span></p>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
	   </div>
	 </div>
	   <div class="contact-w3-agile1 map" data-aos="flip-right">
		 </div>
   <div class="banner_bottom_agile_info">
	<div class="container">
	   <div class="agile-contact-grids">
				
				<div class="clearfix"> </div>
			</div>
       </div>
	</div>
							</header>
						</section>

					<!-- Intro -->
						

				</section>

				

	

		<!-- Scripts -->
			<script src="<?php echo base_url("assets/js/jquery.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/jquery.dropotron.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/browser.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/breakpoints.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/util.js");?>"></script>
			<script src="<?php echo base_url("assets/js/main.js");?>"></script>

	</body>
</html>