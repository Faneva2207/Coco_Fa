<?php include('Include/header.php');?>

					<!-- Banner -->

					<!-- Banner -->		<section id="">
							
						</section>

					<!-- Intro -->
						

				</section>



			<!-- Main -->
				<section id="main">
					<div class="container">
						<div class="row">
							<div class="col-12">

								<!-- Portfolio -->

									<section>
										<header class="major">
											<h2>Nos produits</h2>
										</header>
										<div class="row">
											
											<!--bouclena-->
											<?php foreach ($produitCategorie as $value) {
											?>
											<div class="col-4 col-6-medium col-12-small">
												<section class="box">
													<a href="#" class="image featured"><img src="<?php echo  base_url('assets/sary');?>/<?php echo $value['image'];?>" alt="" /></a>
													<header>
														<h3><?php echo  $value['nomProduit'];?></h3>
													</header>
													<p></p>
													<footer>
														<ul class="actions">
															<li><a href="<?php echo base_url('index.php/welcome/redirectionFicheProduit?id');?>=<?php echo $value['idProduit'];?>" class="button alt">Details</a></li>
														</ul>
													</footer>
												</section>
											</div>
											<?php } ?>
											
										</div>
									</section>

							</div>
							<div class="col-12">

								<!-- Blog -->
									

							</div>
						</div>
					</div>
				</section>
<?php include('Include/footer.php');?>