
			<!-- Footer -->
				<section id="footer">
					<div class="container">
						<div class="row">
							<div class="col-8 col-12-medium">
								<sect
							</div>
							<div class="col-4 col-12-medium">
								
							</div>
							
							<div class="col-4 col-6-medium col-12-small">
								<section>
									<header>
										<h2>Menu</h2>
									</header>
									<ul class="divided">
										<li><a href="<?php echo base_url('index.php/welcome/index');?>">Accueil</a></li>
										<li><a href="<?php echo base_url('index.php/welcome/RedirectionContact');?>">Contact</a></li>
										
									</ul>
								</section>
							</div>
							<div class="col-4 col-12-medium">
								<section>
									<header>
										<h2></h2>
									</header>
									<ul class="social">
										<li><a class="icon fa-facebook" href="#"><span class="label">Facebook</span></a></li>
										<li><a class="icon fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon fa-dribbble" href="#"><span class="label">Dribbble</span></a></li>
										<li><a class="icon fa-tumblr" href="#"><span class="label">Tumblr</span></a></li>
										<li><a class="icon fa-linkedin" href="#"><span class="label">LinkedIn</span></a></li>
									</ul>
									<ul class="contact">
										<li>
											<h3>Adresse</h3>
											<p>
												IJB 123<br />
												Antaninarenina<br />
												
											</p>
										</li>
										<li>
											<h3>email</h3>
											<p><a href="#">nirina.neva@gmail.com</a></p>
										</li>
										<li>
											<h3>Telephone</h3>
											<p>034 95 439 71</p>
										</li>
									</ul>
								</section>
							</div>
							<div class="col-12">

								<!-- Copyright -->
									
						</div>
					</div>
				</section>

		</div>

		<!-- Scripts -->
			<script src="<?php echo base_url("assets/js/jquery.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/jquery.dropotron.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/browser.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/breakpoints.min.js");?>"></script>
			<script src="<?php echo base_url("assets/js/util.js");?>"></script>
			<script src="<?php echo base_url("assets/js/main.js");?>"></script>

	</body>
</html>