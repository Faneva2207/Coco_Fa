<?php include('include/header.php');?>
					<!-- Banner -->
						<section id="banner">

								
	    <div class="container">
		  <div class="form-panel">
              <form action="<?php echo base_url('index.php/welcome/Authentification');?>" method="post"  role="form" class="form-horizontal style-form">
                <div class="form-group has-success">
                  <label class="col-lg-2 control-label">Login</label>
                  <div class="col-lg-10">
                    <input type="text" placeholder="Login" id="Login" name="Login" class="form-control">
                  </div>
                </div>
                 <div class="form-group has-success">
                  <label class="col-lg-2 control-label">Mot de passe</label>
                  <div class="col-lg-10">
                    <input type="password" placeholder="Mot de passe" id="MotDePasse" name="MotDePasse" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-lg-offset-2 col-lg-10">
                    <button class="btn btn-theme" type="submit">Se connecter</button>
                  </div>
                </div>
              </form>
            </div>
	   </div>
	 </div>
	   <div class="contact-w3-agile1 map" data-aos="flip-right">
		 </div>
   <div class="banner_bottom_agile_info">
	<div class="container">
	   <div class="agile-contact-grids">
				
				<div class="clearfix"> </div>
			</div>
       </div>
	</div>
							</header>
						</section>

					<!-- Intro -->
						

				</section>

				

<?php include('Include/footer.php');?>