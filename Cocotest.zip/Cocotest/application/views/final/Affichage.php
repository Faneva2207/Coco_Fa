<?php include('Include/header.php');
	  include(''.$page.'.php');
	  include('Include/footer.php');	