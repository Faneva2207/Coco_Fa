<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Merci mon Dieu</title>
<div>
	<h1>index page index</h1>
</div>

</body>
</html>