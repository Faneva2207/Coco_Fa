<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Ajout produit</title>

  <!-- Favicons -->
  <link href="<?php echo base_url("assete/img/favicon.png");?>" rel="icon">
  <link href="<?php echo base_url("assete/img/apple-touch-icon.png");?>" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url("assete/lib/bootstrap/css/bootstrap.min.css");?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo base_url("assete/lib/font-awesome/css/font-awesome.css");?>" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="<?php echo base_url("assete/css/style.css");?>" rel="stylesheet">
  <link href="<?php echo base_url("assete/css/style-responsive.css");?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url("assete/css/to-do.css");?>">

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Administrateur<span></span></sb></a>
      <!--logo end-->
      
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="login.html">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">Sam Soffes</h5>
          
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Modification</span>
              </a>
            <ul class="sub">
              <li><a href="<?php echo base_url('index.php/welcome/modificationProduit');?>">Produit</a></li>
              <li><a href="<?php echo base_url('index.php/welcome/modifCategorie');?>">Categorie</a></li>
              
            </ul>
          </li>
          
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i>Ajouter produit</h3>
        <!-- SIMPLE TO DO LIST -->
        
        <!--  row -->
        <!-- COMPLEX TO DO LIST -->
        <div class="row mt">
          
          <!-- /col-md-12-->
        </div>
       
       <!-- BASIC FORM VALIDATION -->
        
        <!-- /row -->
        <!-- FORM VALIDATION -->
        <div class="row mt">
          <div class="col-lg-12">
            
            <div class="form-panel">
              <div class="form">
                <form class="cmxform form-horizontal style-form" id="signupForm" method="post" action="<?php echo base_url('index.php/welcome/ajoutProduit');?>">
                  <div class="form-group ">
                    <label for="firstname" class="control-label col-lg-2">Nom produit</label>
                    <div class="col-lg-10">
                      <input class=" form-control" id="nomproduit" name="nomproduit" type="text" />
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="lastname" class="control-label col-lg-2">categorie</label>
                    <div class="col-lg-10">
                 
                      <select name="categorie"  class="form-control" >
                                    <?php foreach($Cat as $cat) { ?>
                                    <option value="<?php echo $cat['idCategorie'];?>"><?php echo $cat['nomCategorie'];?></option>
                                    <?php } ?>
                                
                      </select>
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="username" class="control-label col-lg-2">quantite</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="quantite" name="quantite" type="text" />
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="unite" class="control-label col-lg-2">unite</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="unite" name="unite" type="test" />
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="confirm_password" class="control-label col-lg-2">Image</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="image" name="image" type="text" />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-lg-offset-2 col-lg-10">
                      <button class="btn btn-theme" type="submit">Ok</button>
                      <button class="btn btn-theme04" type="reset">Effacer</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
        <!-- /row -->
        <!-- SORTABLE TO DO LIST -->
        
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>


    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You 

            n delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
          
        </div>
        <a href="todo_list.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?php echo base_url("assete/lib/jquery/jquery.min.js");?>"></script>
  <script src="<?php echo base_url("assete/lib/bootstrap/js/bootstrap.min.js");?>"></script>
  <script class="include" type="text/javascript" src="<?php echo base_url("assete/lib/jquery.dcjqaccordion.2.7.js");?>"></script>
  <script src="<?php echo base_url("assete/lib/jquery.scrollTo.min.js");?>"></script>
  <script src="<?php echo base_url("assete/lib/jquery.nicescroll.js");?>" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="<?php echo base_url("assete/lib/common-scripts.js");?>"></script>
  <!--script for this page-->
  <script src="<?php echo base_url("assete/http://code.jquery.com/ui/1.10.3/jquery-ui.js");?>"></script>
  <script src="<?php echo base_url("assete/lib/tasks.js");?>" type="text/javascript"></script>
  <script>
    jQuery(document).ready(function() {
      TaskList.initTaskWidget();
    });

    $(function() {
      $("#sortable").sortable();
      $("#sortable").disableSelection();
    });
  </script>

</body>

</html>
