<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	/* fonction oanle index*/
	
	
/*	
	
	public  function index($vue='')
	{
		if($vue=='')
		{
			$this->load->view('MonSite/header');
			$this->load->view('MonSite/index');
			$this->load->view('MonSite/footer');
		}
		else
		{
		$this->load->view('MonSite/header');
		$this->load->view('MonSite/'.$vue.'');
		$this->load->view('MonSite/footer');
		}
	}
*/
	public function index(){
	$this->load->model('Fonction');
	$data=array();
	$data['Categorie']=$this->Fonction->Categorie();		
	$data['Produit1']=$this->Fonction->ProduitCat1();	
	$data['Produit2']=$this->Fonction->ProduitCat2();
	$data['Produit3']=$this->Fonction->ProduitCat3();
	$data['AllProduit']=$this->Fonction->AllProduit();
	$data['page']='index';

	$this->load->view('final/index', $data);
	}

	public function RedirectionAbout(){

		
        $this->load->view('page/About');
	}
	public function RedirectionContact(){

		$this->load->model('Fonction');
		$data=array();
		$data['Categorie']=$this->Fonction->Categorie();
        $this->load->view('final/Contact', $data);
	}

	public function Administrateur()
	{
		$this->load->view('administrateur/index');
	}
	public function Connexion()
	{
		$this->load->model('Fonction');
		$data=array();
		$data['Categorie']=$this->Fonction->Categorie();
		$this->load->view('final/Connexion', $data);
	}
	public function Authentification()
	{
		$this->load->model('Fonction');

		$Login=$this->input->post('Login');
		$MotDePasse=$this->input->post('MotDePasse');
		$data=array();

		$data['login']=$Login;

		$data['logintest']=$this->Fonction->testLogin($Login, $MotDePasse);

		$data['AllProduit']=$this->Fonction->Allproduit();

		$data['Categorie']=$this->Fonction->Categorie();
		
		foreach($data['logintest'] as $value)
		{
			$data['andrana']=$value['count(*)'];
			$andramana=$data['andrana'];
		}

		if($andramana != 0)
		{
			
			$this->load->view('administrateur/indexx', $data);
		}
		else if($andramana == 0)
		{
			$this->load->view('final/Connexion', $data);
		}

		
	}
	public function suppression()
	{
		$this->load->model('Fonction');
		$fafaina=$this->input->get('fafaina');
		$data=array();
		$data['AllProduit']=$this->Fonction->Allproduit();
		$data['Categorie']=$this->Fonction->Categorie();

		$data['suppression']=$this->Fonction->suppression($fafaina);
		$this->load->view('administrateur/modificationProduit', $data);
	}
	
	public function modifCategorie()
	{
		$this->load->model('Fonction');
		$data=array();
		$data['AllProduit']=$this->Fonction->Allproduit();
		$data['Categorie']=$this->Fonction->Categorie();
		
		$this->load->view('administrateur/Categorie', $data);
	}
	public function modificationProduit()
	{
		$this->load->model('Fonction');
		$data=array();
		$data['AllProduit']=$this->Fonction->Allproduit();
		$data['Categorie']=$this->Fonction->Categorie();
		
		$this->load->view('administrateur/ModificationProduit', $data);
	}
	public function suppressionCategorie()
	{
		$this->load->model('Fonction');
		$fafaina=$this->input->get('fafaina');
		$data=array();
		$data['AllProduit']=$this->Fonction->Allproduit();
		$data['Categorie']=$this->Fonction->Categorie();
		$fafainaCategorie=$this->input->get('suppressionCategorie');
		$data['suppressionCategorie']=$this->Fonction->suppCategorie($fafaina);
		
		$this->load->view('administrateur/Categorie', $data);
	}
	public function redirectionAjoutCategorie()
	{
		$this->load->model('Fonction');
		$data=array();

		$this->load->view('administrateur/ajoutCategorie', $data);
	}
	public function redirectionAjoutproduit()
	{
		$this->load->model('Fonction');

		$data=array();


		$data['Cat']=$this->Fonction->Categorie();



		$this->load->view('administrateur/ajoutProduit', $data);
	}

	public function ajoutCategorie()
	{
		$this->load->model('Fonction');

		$data=array();

		$atsofoka=$this->input->post('nomCategorie');

		$data['insertion']=$this->Fonction->insertionCategorie($atsofoka);

		$this->load->view('administrateur/ajoutCategorie', $data);
	}
	public function ajoutProduit()
	{
		$this->load->model('Fonction');

		$data=array();

		$data['Cat']=$this->Fonction->Categorie();

		$nom=$this->input->post('nomproduit');
		$cat=$this->input->post('categorie');
		$quantite=$this->input->post('quantite');
		$unite=$this->input->post('unite');
		$image=$this->input->post('image');

		
		$data['insertionProduit']=$this->Fonction->insertionProduit($nom, $cat, $quantite, $unite, $image);


		$this->load->view('administrateur/ajoutProduit', $data);
	}

	public function redirectionModificationC(){
		$this->load->model('Fonction');

		$data=array();

		$get=$this->input->get('ovaina');

		$data['CategorieCondition']=$this->Fonction->CategorieCondition($get);
		
		$this->load->view('administrateur/ModificationC', $data);
	}
	public function modificationC(){
		$this->load->model('Fonction');

		$data=array();

		$post=$this->input->post('nomCategorie');

		$get=$this->input->get('ovaina');

		$data['CategorieCondition']=$this->Fonction->CategorieCondition($get);

		$data['updateC']=$this->Fonction->updateC($post, $get);

		$this->load->view('administrateur/ModificationC', $data);
	}

	public function redirectionModificationP(){
		$this->load->model('Fonction');

		$data=array();

		$get=$this->input->get('ovaina');

		$data['ProduitCondition']=$this->Fonction->ProduitCondition($get);
		
		$this->load->view('administrateur/ModificationP', $data);
	}
	public function modificationP(){
		$this->load->model('Fonction');

		$data=array();

		$post=$this->input->post('nomproduit');
		$post2=$this->input->post('categorie');
		$post3=$this->input->post('quantite');
		$post4=$this->input->post('unite');
		$post5=$this->input->post('image');


		$get=$this->input->get('ovaina');

		$data['ProduitCondition']=$this->Fonction->ProduitCondition($get);

		$data['updateP']=$this->Fonction->updateP($post, $post2, $post3, $post4, $post5, $get);

		$this->load->view('administrateur/ModificationP', $data);
	}
	public function redirectionParCategorie()
	{
		$this->load->model('Fonction');
		$data=array();
		$data['Categorie']=$this->Fonction->Categorie();
		$get=$this->input->get('categorie');
		$data['produitCategorie']=$this->Fonction->produitCategorie($get);

		$this->load->view('final/parCategorie', $data);
	}	
		public function redirectionFicheProduit()
	{
		$this->load->model('Fonction');
		$data=array();
		$data['Categorie']=$this->Fonction->Categorie();
		$get=$this->input->get('id');
		$data['ProduitCondition']=$this->Fonction->ProduitCondition($get);
		foreach($data['ProduitCondition'] as $value)
		{
			$variable= $value['idCategorie'];
			$data['CategorieCondition']=$this->Fonction->CategorieCondition($variable);
			foreach($data['CategorieCondition'] as $val)
			{
				$data['nomCategorie']=$val['nomCategorie'];
			}
		}


		$this->load->view('final/FicheProduit', $data);
	}	
	
}

