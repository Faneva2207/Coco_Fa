create table categorie(
	idCategorie int primary key AUTO_INCREMENT,
	nomCategorie varchar(20)
);
create table administrateur(
	idAdministrateur int primary key AUTO_INCREMENT,
	login varchar(20),
	mdp varchar(20)
);
insert into administrateur values (null, 'Andrana', 'Andrana');
insert into administrateur values (null, 'Faneva', 'Faneva');

insert into categorie values (null, 'jus');
insert into categorie values (null, 'lait'); 
insert into categorie values (null, 'poudre');

create table produit(
    idProduit int primary key AUTO_INCREMENT,
    nomProduit varchar(20),
    idCategorie int,
    quantite int,
 unite varchar(10),
image varchar(70),
foreign key (idCategorie) references categorie(idCategorie)
);
insert into produit value(null,'choco coco',1,35,'cl','g.jpg');
insert into produit value(null,'Coco fraise',1,1,'l','h.jpg');
insert into produit value(null,'choco coco',1,35,'cl','c.jpg');
insert into produit value(null,'Coco vanille',1,25,'cl','d.jpg');

insert into produit value(null,'lait de coco pure',2,10,'cl','a.jpg');
insert into produit value(null,'lait parfum choco',2,10,'cl','q.jpg');

insert into produit value(null,'poudre maina',3,1,'kg','i.jpg');
insert into produit value(null,'poudre lena ',3,500,'g','m.jpg');


